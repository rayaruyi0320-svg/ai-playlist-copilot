# Public source package

This archive contains the local Next.js and TypeScript UI prototype, mock data, product flows, UX copy, and a low-fidelity wireframe. It has no production Spotify or LLM integration and no real API credentials.

Run `pnpm install` and `pnpm dev` in this folder, then open http://127.0.0.1:3000. The interface is a prototype with mock content.

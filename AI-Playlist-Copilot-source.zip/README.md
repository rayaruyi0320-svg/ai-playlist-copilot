# Playlist Copilot

Generate personalized Spotify playlists from natural language based on the
user's own music library.

Playlist Copilot is a personal music retrieval app. The product is not trying
to recommend random new songs from the global catalog. Its first job is to help
people quickly find the right tracks from music they already like.

## Product Goal

Users connect Spotify, describe what they want to hear in plain language, and
Playlist Copilot turns that request into a playlist from their synced library.

Example:

```text
15-min shower, upbeat R&B
```

The app should understand the scene, search the user's own library, create the
playlist in Spotify, and return an Open in Spotify link.

## MVP Scope

V1.0 includes:

- Spotify OAuth login.
- Sync at least 200 liked songs.
- Store searchable song metadata.
- Parse natural language prompts with DeepSeek into structured parameters.
- Search and rank tracks from the user's own library.
- Create a Spotify playlist and add selected tracks.
- Show playlist result, history, and basic settings.
- Handle empty prompts, low confidence, no results, expired sessions, and API
  failures with clear copy.

V1.0 does not include:

- Apple Music, NetEase Cloud Music, QQ Music, or other platforms.
- Machine learning model training.
- Vector database search.
- Global music recommendation outside the user's library.
- A full chat agent or advanced playlist editing.

## Current Build

This repository currently contains the static MVP shell:

- Next.js App Router.
- TypeScript.
- TailwindCSS.
- Responsive pages for Landing, Login, Syncing, Home, Generating, Result,
  History, and Settings.
- Mock playlist result and mock prompt history.
- No Spotify or DeepSeek integration yet.
- No real secrets.

## Development Plan

1. Static UI shell with mock data.
2. Spotify OAuth and secure session handling.
3. Library sync for liked songs and playlists.
4. Local database schema for songs, generated playlists, and prompt history.
5. DeepSeek prompt parser with JSON validation and confidence handling.
6. Retrieval and ranking from the synced library.
7. Spotify playlist creation.
8. History, retries, and full error-state polish.
9. Vercel deployment and portfolio documentation.

## Local Setup

Install dependencies:

```bash
pnpm install
```

Run the app:

```bash
pnpm dev
```

Open:

```text
http://127.0.0.1:3000
```

Check TypeScript:

```bash
pnpm typecheck
```

Create a local environment file when integrations begin:

```bash
cp .env.example .env.local
```

Do not commit real Spotify, DeepSeek, database, or auth secrets.
